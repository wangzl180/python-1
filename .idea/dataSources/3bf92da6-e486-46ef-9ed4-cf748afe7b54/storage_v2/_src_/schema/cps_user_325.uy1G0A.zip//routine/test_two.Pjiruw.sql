create procedure test_two()
begin
declare i int default 0;
while i < 2 do
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,1,100,0,0,NULL,NULL,NULL,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,1,110,0,0,NULL,NULL,NULL,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,1,120,0,0,NULL,NULL,NULL,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,1,0,100,100,UNIX_TIMESTAMP('2019-01-09 18:55:37'),NULL,0,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,1,0,100,100,UNIX_TIMESTAMP('2019-01-09 18:55:37'),NULL,0,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,2,0,0,0,NULL,NULL,2,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,3,150,150,150,UNIX_TIMESTAMP('2019-01-09 18:55:37'),NULL,0,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,3,150,150,150,UNIX_TIMESTAMP('2019-01-09 18:55:37'),NULL,0,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,4,0,0,0,NULL,NULL,1,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
INSERT INTO recharge (user_id,type,kandian,free_kandian,remain_free_kandian,free_endtime,vip_starttime,`day`,`hour`,book_id,createtime,updatetime,notes) VALUE (i,5,0,20,20,UNIX_TIMESTAMP('2019-01-09 18:55:37'),NULL,0,NULL,NULL,UNIX_TIMESTAMP(NOW()),UNIX_TIMESTAMP(NOW()),NULL);
set i = i + 1;
end while;
end;

