create procedure alter_table(IN total int)
BEGIN
    DECLARE i INT DEFAULT 0;
    WHILE i < total DO
      set @sql = concat("ALTER TABLE `cps_user_",i,"`.`user`
	ADD COLUMN `is_first_unfollow` enum('0','1','2') NOT NULL DEFAULT '2' COMMENT '是否首次取消关注:0=否,1=是,2=未取关';");
      set i = i + 1;
      PREPARE stat from @sql;
      EXECUTE stat;
      DEALLOCATE PREPARE stat;
    END WHILE;
  END;

